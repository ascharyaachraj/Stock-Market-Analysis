// After getting the basic quote data
$quote = $data['Global Quote'];

// Get company overview for sector information
$overviewUrl = "https://www.alphavantage.co/query?function=OVERVIEW&symbol={$symbol}&apikey=" . ALPHA_VANTAGE_API;
$overviewResponse = json_decode(file_get_contents($overviewUrl), true);

// Get historical data (last 30 days)
$historicalUrl = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={$symbol}&apikey=" . ALPHA_VANTAGE_API;
$historicalResponse = json_decode(file_get_contents($historicalUrl), true);

// Build final response
$stockData = [
    'symbol' => $symbol,
    'price' => $quote['05. price'],
    'change' => $quote['09. change'],
    'changePercent' => rtrim($quote['10. change percent'], '%'),
    'sector' => $overviewResponse['Sector'] ?? 'N/A',
    'history' => [],
    'lastUpdated' => date('Y-m-d H:i:s')
];

// Process historical data
if (isset($historicalResponse['Time Series (Daily)'])) {
    $counter = 0;
    foreach ($historicalResponse['Time Series (Daily)'] as $date => $values) {
        if ($counter++ >= 30) break; // Limit to 30 days
        $stockData['history'][] = [
            'date' => $date,
            'open' => $values['1. open'],
            'high' => $values['2. high'],
            'low' => $values['3. low'],
            'close' => $values['4. close'],
            'volume' => $values['5. volume']
        ];
    }
    // Reverse to show oldest first
    $stockData['history'] = array_reverse($stockData['history']);
}