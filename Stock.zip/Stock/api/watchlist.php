<?php
require_once '../config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'error' => 'Not authenticated']);
        exit();
    }

    $data = json_decode(file_get_contents('php://input'), true);
    $symbol = strtoupper($conn->real_escape_string($data['symbol']));

    $stmt = $conn->prepare("DELETE FROM watchlist WHERE user_id = ? AND stock_symbol = ?");
    $stmt->bind_param("is", $_SESSION['user_id'], $symbol);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
}
?>